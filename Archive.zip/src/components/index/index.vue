<template>
  <div class="page__index">

  </div>
</template>

<script>

  import q from 'q'
  import ReconnectingWebsocket from 'reconnecting-websocket'
  import constants from '@/utils/constants'
  export default {
    name: 'hello',
    data () {
      return {
        websocket: null,
        requestId: 0,
        callbacks: []
      }
    },
    created () {
//      var self = this
//      this.websocket = new ReconnectingWebsocket(constants.WS_URL)
//      this.websocket.onopen = () => {
//        console.log('socket opened')
//        setInterval(() => {
//          self.websocket.send('PING')
//        }, 10000)
//
//        self.request(constants.socketAPI.userPostSession).then(function(resp) {
//          console.log('promise post session')
//          setTimeout(() => {
//            self.request(constants.socketAPI.courseGetInfo).then(function(resp) {
//              console.log('promise get info1')
//              console.log(resp)
//              self.request(constants.socketAPI.courseGetInfo).then(function(resp) {
//                console.log('promise inner get info3')
//                console.log(resp)
//              })
//            })
//          },1000)
//          self.request(constants.socketAPI.courseGetInfo).then(function(resp) {
//            console.log('promise get info2')
//            console.log(resp)
//          })
//        })
//
//      }
//      this.websocket.onmessage = (res) => {
//        if(res.data == 'PONG') {
//          console.log('PONG')
//        } else {
//          let respData = JSON.parse(res.data)
//          let requestId = respData['s']
//          if(self.callbacks[requestId]) {
//            let callback = self.callbacks[requestId];
//            delete self.callbacks[requestId ];
//            callback.resolve(respData);
//          }
//        }
//      }
    },
    methods: {
      getRequestId() {
        return this.requestId++
      },
      request(api) {
        let requestId = this.getRequestId()
        let deferred = q.defer()
        this.callbacks[requestId] = deferred
        this.websocket.send(JSON.stringify(api(requestId)))
        return deferred.promise.then(function(resp) {
          return resp
        })
      }
    }

  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
