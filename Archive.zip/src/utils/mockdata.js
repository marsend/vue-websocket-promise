/**
 * Created by miaUser on 01/11/2017.
 */
export default {
  user: {
    guid: 'd542be628b18e29b33bba6fa56bf47edguid',
    ID: '77155',
    token: 'bff8061abdc67986daf22aec90f412e7_1509527521'
  }
}
