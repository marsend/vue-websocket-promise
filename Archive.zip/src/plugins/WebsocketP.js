/**
 * Created by miaUser on 08/11/2017.
 */
import ReconnectingWebsocket from 'reconnecting-websocket'
import constants from '@/utils/constants'
let _Vue
let WebsocketP = {}

var isDef = function (v) { return v !== undefined; };

function install (Vue, Options) {
  if (install.installed && _Vue == Vue) {return}
  install.installed = true
  _Vue = Vue

  Vue.mixin({
    created: () => {
      console.log(this)
      console.log('websocketp created')
      debugger
      console.log(this._websocketP)
      if(!isDef(this._websocketP)) {
        this._websocketP = new ReconnectingWebsocket(constants.WS_URL)
      }
    }
  })
}

WebsocketP.install = install

export default WebsocketP
